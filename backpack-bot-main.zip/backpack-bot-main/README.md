
-Pairs: $SOL/$USDC
en az 10 usdc ile çalışır



1-BACKPACK GIR

2. BACKPACK API OLUSTUR 
backpack: https://backpack.exchange/settings/api-keys)

index.js dosyasını not defteri veya text editör ile açın  içinde api tırnak içine girin 

3. NodeJS YUKLE : https://nodejs.org/dist/v20.12.1/node-v20.12.1-x64.msi

4. WINDOWS CMD  Mac terminal AÇIN

5-Dosyanın olduğu klasöre windows cmd Mac terminal üzerinden dizine geçin 

windows da klasörün olduğu dizin kısmına CMD yazıp enter basarsanız oto cmd gerekli dizinde çalışır

kodları sırayla girin 

1. kod 

```
npm install
```
2. kod

```
node ./index.js
```

buy sell kısımlarını 1dk sonra kontrol edin sayı artıyorsa sorunsuz başlamıştır
